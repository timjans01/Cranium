namespace cryptolens_io {

namespace v20190401 {

namespace internal {

int activate_parse_server_error_message(char const* server_response);

} // namespace internal

} // namespace v20190401

} // namespace cryptolens_io
