namespace cryptolens_io {

namespace v20190401 {

namespace internal {

bool Curl_isunreserved(unsigned char in);

} // namespace internal

} // namespace v20190401

} // namespace cryptolens_io
