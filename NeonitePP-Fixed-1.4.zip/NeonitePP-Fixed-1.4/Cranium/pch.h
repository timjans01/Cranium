#ifndef PCH_H
#define PCH_H

#define CONSOLE
#define SSL_BYPASS
#define HOOKS
//#define INJECT_ASAP


#include "framework.h"

#endif // PCH_H
